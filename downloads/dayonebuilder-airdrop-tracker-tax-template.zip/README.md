# Airdrop Tracker + DeFi Tax Template Starter

This free starter bundle is for crypto users who need one place to track airdrop hunts, token receipts, and later disposal notes without rebuilding the sheet every time.

## Included file

- `airdrop-tracker-tax-template-starter.xml` — multi-tab spreadsheet template for Excel / LibreOffice / Numbers-compatible apps

## Tabs

- `Instructions` — fast setup steps and scope boundaries
- `Airdrops` — campaign list, wallet, status, claim link, proof link, and receipt fields
- `Tax Lots` — token receipt date, quantity, estimated fair market value, and holding start
- `Disposals` — sales, swaps, and other exits tied back to the receipt lot
- `Summary` — open campaigns, receipt value, proceeds, and logged gain/loss totals

## Scope note

This is a practical tracking starter, not tax advice. Use local rules before filing.
