# Wallet P&L Calculator Starter

This free browser bundle is for crypto users who need a fast wallet-level sanity check before they trust a messy total.

## Included files

- `wallet-pnl-calculator.html` - standalone browser calculator
- `calculator.css` - shared styles for the calculator
- `calculator.js` - wallet P&L math and browser behavior

## What it calculates

- total P&L from deposits, withdrawals, and current holdings value
- total return percent when deposits are above zero
- net capital still in play
- realized cost basis based on the basis still attached to the open position
- rough realized P&L and unrealized P&L

## Assumptions

- deposits and withdrawals mean external capital in and out
- internal transfers between your own wallets are excluded
- current holdings cost basis is estimated by the user
- realized plus unrealized equals total when that estimate is internally consistent

## Scope note

This is a quick wallet-level decision aid. It does not cover tax lots, gas, staking accrual detail, or chain-specific accounting edge cases.
