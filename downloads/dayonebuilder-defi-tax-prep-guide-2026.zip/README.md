# DeFi Tax Prep Guide 2026 Starter

This free bundle is for DeFi users who want cleaner records before swaps, bridges, LP moves, rewards, and airdrops turn into a year-end reconstruction project.

## Included files

- `defi-tax-prep-guide-2026.md` - main guide for what to capture now and how to keep the trail usable later
- `record-source-checklist.md` - source checklist so you do not rely on one export and hope it was complete
- `defi-event-classification-matrix.csv` - working matrix for common DeFi event types and the notes worth saving
- `cleanup-mistakes-checklist.md` - fast checklist for the mistakes that make tax cleanup harder
- `wallet-and-source-inventory.csv` - starter inventory for wallets, exchange accounts, and saved exports

## Scope note

This is a recordkeeping prep pack, not tax advice. Use your local rules before filing.
