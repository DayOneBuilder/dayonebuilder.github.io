# DeFi Tax Prep Guide 2026

This guide is for the part of tax prep people skip until it hurts: getting the raw record trail into decent shape before software imports or a preparer review.

The goal is simple:
- know which wallets, exchanges, and chains belong to you
- save the exports and screenshots that explain what happened
- label common DeFi events before memory fills the gaps with guesses

Use the other files in this bundle as you go.

## 1. Start with one owner map

Fill in `wallet-and-source-inventory.csv` first.

At minimum, list:
- every wallet address you used
- every exchange or CEX account tied to the same activity
- the chain or platform for each item
- what it was used for: swaps, LP, staking, farming, perps, bridging, lending
- whether you already saved a raw export or need to go pull it

If a wallet or exchange account is missing from this list, it will usually go missing again later when you try to reconcile transfers.

## 2. Save raw sources before you clean anything

Pull exports and evidence before you start re-labeling transactions.

Good sources to save:
- wallet explorer pages for each address and chain
- exchange CSV exports
- protocol dashboards or position history pages
- bridge confirmations from both sides of the move
- claim pages or reward pages for airdrops and farm payouts
- price notes for low-liquidity tokens where the value will be harder to defend later

Use `record-source-checklist.md` as the pull list. Save the raw files first. Cleaned spreadsheets come second.

## 3. Keep one working rule for timestamps and labels

Pick a time standard and stick to it. UTC is the least annoying choice when you are merging wallet, protocol, and exchange records.

Use the same labels everywhere:
- wallet labels that match your own notes
- protocol names written the same way each time
- token symbols checked against the contract, not memory
- short notes for weird events instead of leaving them unlabeled

Messy naming is how same-owner transfers end up looking like buys, sells, or mystery income.

## 4. Classify common DeFi events before year-end

Open `defi-event-classification-matrix.csv` and work through the event types you actually used.

The point is not to force a legal answer for every line item. The point is to stop pretending all DeFi activity belongs in one generic "swap" bucket.

Working rule:
- if the event is clearly same-owner movement, save both sides and mark it that way
- if the event changes what you own, what you received, or when income may have started, save the exact receipt details
- if the event is tricky, flag it for review instead of inventing certainty

The highest-friction buckets are usually:
- bridges where one side is missing
- LP adds and removals
- reward claims with no saved value note
- liquidations, debt settlements, or protocol-specific restructures

## 5. Capture the minimum details while you still can

For any event that might matter later, try to keep:
- date and time in UTC
- wallet or account involved
- chain and protocol
- transaction hash or internal reference
- token symbols and quantities in and out
- fees paid in a separate note when visible
- price source or fair-market-value note when a receipt matters
- one short explanation if the event is not obvious from the transaction alone

This is boring work. It is also the difference between a defendable trail and a spreadsheet full of "probably."

## 6. Do a monthly close, not one giant panic session

If the activity matters enough to file, it matters enough to close once a month.

Each close can be short:
1. update the inventory file if a new wallet or account appeared
2. pull missing exports for the month
3. label any new bridge, LP, reward, or airdrop events
4. note missing prices or unresolved transactions while the context is still fresh

That one habit is what keeps cleanup from turning into detective work later.

## 7. What this guide does not try to do

This bundle does not replace tax software, a preparer, or local rules. It gives you a cleaner handoff pack:
- wallet and source inventory
- saved exports and screenshots
- a working event classification matrix
- a short list of mistakes to fix before they compound

If you hand off clean records, the hard part gets smaller.
