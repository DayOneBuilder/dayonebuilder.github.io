# Record And Source Checklist

Use this before you start cleanup work inside a spreadsheet or tax app.

## Core inventory

- List every wallet address you used this year.
- List every exchange or custodial account tied to the same activity.
- Note each chain and what the wallet or account was mainly used for.
- Mark whether you already saved a raw export for each source.

## Raw files to save

- Explorer history for each wallet and chain you used.
- Exchange CSV exports for spot, earn, margin, or derivatives accounts you touched.
- Protocol dashboards or account-history pages for lending, staking, farming, or perps.
- Bridge records from both the origin and destination side.
- Claim pages or protocol pages for airdrops, rebates, and reward claims.
- Any manual price notes for low-liquidity tokens or thin markets.

## What to name and note

- Pull date in UTC.
- Coverage period.
- Wallet label or account label.
- Chain or platform.
- File source.
- Anything obviously missing.

## Folder layout that stays readable

- `01-wallet-inventory`
- `02-wallet-exports`
- `03-exchange-exports`
- `04-protocol-history`
- `05-bridges-and-claims`
- `06-price-notes`
- `07-review-notes`

## Sanity checks before you move on

- Do not rely on one aggregator export as your only source.
- Do not overwrite the raw export after you clean it.
- Do not assume bridge history, LP history, or reward history will still be easy to find later.
- Do not leave unexplained wallets out of the inventory because they only had "a few transactions."
