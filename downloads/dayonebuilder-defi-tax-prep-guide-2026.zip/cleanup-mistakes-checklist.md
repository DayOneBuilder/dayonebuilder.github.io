# Cleanup Mistakes Checklist

Fix these early if they describe your records.

- I never wrote down every wallet and exchange account involved.
- I am treating same-owner transfers like mystery buys or sells because the labels are inconsistent.
- I saved one side of a bridge but not the other.
- I have reward or airdrop receipts with no date, quantity, or value note.
- I left LP adds and removals in a generic unlabeled bucket.
- I cleaned exports in place and lost the raw source file.
- I am relying on a protocol dashboard without saving the page or export it came from.
- I have thin-market tokens with no saved pricing note.
- I am guessing which wallet paid the fee because I did not keep the tx hash nearby.
- I keep saying I will fix it later, but I have not done one monthly close.

## Fast fix order

1. Rebuild the wallet and account inventory.
2. Pull missing raw exports and screenshots.
3. Match bridges and same-owner transfers.
4. Log reward, airdrop, and other receipt details.
5. Flag hard LP or liquidation events for review instead of forcing them into the wrong bucket.
