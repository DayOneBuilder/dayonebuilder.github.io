# Impermanent Loss Calculator Starter

This free browser bundle is for DeFi users who want a straight answer before they tell themselves the fees probably covered the damage.

## Included files

- `impermanent-loss-calculator.html` - standalone browser calculator
- `calculator.css` - shared styles for the calculator
- `calculator.js` - LP math and browser behavior

## What it calculates

- hold value after the price move
- LP value before fees
- LP value after your fee or incentive estimate
- impermanent loss percent vs hold
- impermanent loss dollars vs hold
- fee income needed to close the gap

## Assumptions

- 50/50 constant-product pool
- token A price move measured relative to token B
- token B used as the quote side for the dollar view
- fee income entered manually

## Scope note

This is a quick decision aid. It does not cover concentrated liquidity, gas, taxes, compounding, or execution risk.
